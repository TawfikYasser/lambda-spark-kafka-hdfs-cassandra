package com.datastax.spark.connector.util

object Quote {

   def quote(name: String): String = "\"" + name + "\""

 }
