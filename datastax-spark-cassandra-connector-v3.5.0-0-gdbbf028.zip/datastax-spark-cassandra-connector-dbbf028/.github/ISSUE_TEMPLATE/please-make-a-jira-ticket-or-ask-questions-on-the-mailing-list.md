---
name: Please Make a Jira Ticket or Ask Questions on the Mailing List
about: How to get help and report Bugs
title: You shouldn't be making this issue :)
labels: ''
assignees: ''

---

For issue tracking we use [JIRA](https://datastax-oss.atlassian.net/projects/SPARKC)
Datastax managed QA at [Datastax Community](https://community.datastax.com/index.html)
Questions can be posted to the [mailing list](https://groups.google.com/a/lists.datastax.com/forum/#!forum/spark-connector-user).
