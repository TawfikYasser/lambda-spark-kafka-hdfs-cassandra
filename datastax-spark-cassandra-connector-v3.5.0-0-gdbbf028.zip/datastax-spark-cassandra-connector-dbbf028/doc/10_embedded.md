# Documentation

# Spark-Connector-Embedded No Longer Supported

_Note that this artifact was removed 2.5 and newer. Spark Cassandra Connector integration
tests rely on [ccm](https://github.com/riptano/ccm)._

Please see the `test-support` package for more info about our new CCM based integration testing framework
    
## Examples

[Next - Performance Monitoring](11_metrics.md)
