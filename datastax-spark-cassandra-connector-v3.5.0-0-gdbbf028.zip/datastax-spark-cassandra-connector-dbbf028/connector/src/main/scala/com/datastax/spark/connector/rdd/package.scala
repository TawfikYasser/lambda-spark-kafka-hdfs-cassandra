package com.datastax.spark.connector


/** Contains [[com.datastax.spark.connector.rdd.CassandraTableScanRDD]] class that is the main entry point for
  * analyzing Cassandra data from Spark. */
package object rdd {

}
