package com.datastax.spark.connector.util


/**
  * Do not remove.
  * This is a temporary marker class that is loaded by name during application shutdown.
  * See SPARKC-620 for details.
  */
object ClassLoaderCheck {}

